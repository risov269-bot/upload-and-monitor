import os
import time
import hashlib
import shutil
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from github import Github, GithubException, BadCredentialsException, UnknownObjectException
import threading
from datetime import datetime

class FolderMonitor:
    def __init__(self, local_folder, github_token, repo_name, branch="main"):
        self.local_folder = Path(local_folder)
        self.github_token = github_token
        self.repo_name = repo_name
        self.branch = branch
        self.last_sync = {}
        self.sync_lock = threading.Lock()
        self.sync_queue = set()
        self.sync_timer = None
        # Ignore patterns (directories or filename globs)
        self.ignore_dirs = {"node_modules", ".git", ".venv", "__pycache__"}
        self.ignore_globs = set()
        
        # Initialize GitHub connection
        self.g = Github(github_token, per_page=100)
        self.local_folder.mkdir(parents=True, exist_ok=True)

        # Validate token and get current user
        try:
            user = self.g.get_user()
            self.authed_user = user
            self.authed_login = user.login
            print(f"🔐 Authenticated as: {self.authed_login}")
        except BadCredentialsException:
            print("❌ GitHub authentication failed (401). Your token is invalid, expired, or lacks required scopes.")
            print("- Ensure you created a Personal Access Token (classic) with 'repo' scope")
            print("- Update GITHUB_TOKEN in .env and try again")
            raise
        except Exception as e:
            print(f"❌ Failed to validate GitHub token: {e}")
            raise

        # Determine desired owner/name
        desired_owner = None
        repo_name_only = None
        if "/" in self.repo_name:
            desired_owner, repo_name_only = self.repo_name.split("/", 1)
        else:
            repo_name_only = self.repo_name
            desired_owner = self.authed_login
            self.repo_name = f"{desired_owner}/{repo_name_only}"

        # Try to get or create repository
        try:
            self.repo = self.g.get_repo(self.repo_name)
            print(f"🔗 Connected to existing GitHub repo: {self.repo_name}")
        except UnknownObjectException:
            # Repo not found; create under the authenticated user regardless of desired owner
            print(f"🔍 Repository not found: {self.repo_name}. Creating: {self.authed_login}/{repo_name_only}")
            try:
                self.repo = self.authed_user.create_repo(repo_name_only, private=True)
                self.repo_name = f"{self.authed_login}/{repo_name_only}"
                print(f"✅ Created new repository: {self.repo_name}")
            except Exception as create_error:
                # If repo already exists (HTTP 422), connect to it
                if isinstance(create_error, GithubException) and getattr(create_error, 'status', None) == 422:
                    try:
                        self.repo = self.g.get_repo(f"{self.authed_login}/{repo_name_only}")
                        self.repo_name = f"{self.authed_login}/{repo_name_only}"
                        print(f"🔗 Connected to existing repo after 422: {self.repo_name}")
                    except Exception as e2:
                        print(f"❌ Failed to connect to existing repository after 422: {e2}")
                        raise
                else:
                    print(f"❌ Failed to create repository: {create_error}")
                    raise
        except BadCredentialsException:
            print("❌ GitHub authentication failed when accessing repository.")
            raise
        except Exception as e:
            print(f"❌ Error accessing repository: {e}")
            raise

        print(f"📁 Monitoring folder: {self.local_folder}")
        
    def get_file_hash(self, file_path):
        """Calculate MD5 hash of a file"""
        try:
            hash_md5 = hashlib.md5()
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except Exception as e:
            print(f"⚠️  Error calculating hash for {file_path}: {e}")
            return None
    
    def is_ignored(self, path: Path) -> bool:
        """Return True if path matches an ignore rule."""
        try:
            # Normalize to Path
            p = Path(path)
            # Check any dir in path matches ignore_dirs
            for part in p.parts:
                if part in self.ignore_dirs:
                    return True
            # Check globs
            rel = p.relative_to(self.local_folder) if self.local_folder in p.parents or p == self.local_folder else p
            for pattern in self.ignore_globs:
                if rel.match(pattern):
                    return True
        except Exception:
            pass
        return False
    
    def get_github_file_path(self, local_path):
        """Convert local path to GitHub path"""
        relative_path = Path(local_path).relative_to(self.local_folder)
        return str(relative_path).replace("\\", "/")
    
    def upload_file(self, file_path):
        """Upload or update a file on GitHub"""
        try:
            # Ignore unwanted paths
            if self.is_ignored(Path(file_path)):
                return
            github_path = self.get_github_file_path(file_path)
            
            # Read file content
            with open(file_path, 'rb') as f:
                content = f.read()
            
            # Check if file exists on GitHub
            try:
                contents = self.repo.get_contents(github_path, ref=self.branch)
                # Update existing file
                self.repo.update_file(
                    path=github_path,
                    message=f"Update {github_path} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    content=content,
                    sha=contents.sha,
                    branch=self.branch
                )
                print(f"✅ Updated: {github_path}")
            except Exception:
                # Create new file
                self.repo.create_file(
                    path=github_path,
                    message=f"Add {github_path} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    content=content,
                    branch=self.branch
                )
                print(f"➕ Created: {github_path}")
                
        except Exception as e:
            print(f"❌ Error uploading {file_path}: {e}")
    
    def delete_file(self, file_path):
        """Delete a file from GitHub"""
        try:
            github_path = self.get_github_file_path(file_path)
            contents = self.repo.get_contents(github_path, ref=self.branch)
            
            self.repo.delete_file(
                path=github_path,
                message=f"Delete {github_path} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                sha=contents.sha,
                branch=self.branch
            )
            print(f"🗑️  Deleted: {github_path}")
            
        except Exception as e:
            print(f"❌ Error deleting {file_path}: {e}")
    
    def delete_all_repo_files(self):
        """Delete all files from the repository branch (recursively)."""
        try:
            stack = [""]  # start from repo root
            files_deleted = 0
            while stack:
                path = stack.pop()
                try:
                    contents = self.repo.get_contents(path, ref=self.branch)
                except Exception as e:
                    # Empty repo or path not found
                    continue
                if not isinstance(contents, list):
                    contents = [contents]
                for item in contents:
                    if item.type == "dir":
                        stack.append(item.path)
                    else:
                        try:
                            self.repo.delete_file(
                                path=item.path,
                                message=f"Delete {item.path} - reset repo {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                                sha=item.sha,
                                branch=self.branch,
                            )
                            files_deleted += 1
                            print(f"🗑️  Deleted from repo: {item.path}")
                        except Exception as de:
                            print(f"⚠️  Failed to delete {item.path}: {de}")
            print(f"✅ Repo reset complete. Files deleted: {files_deleted}")
        except Exception as e:
            print(f"❌ Error during repo reset: {e}")
    
    def upload_all_local_files(self):
        """Upload all local files (respecting ignore rules)."""
        uploaded = 0
        for file_path in self.local_folder.rglob("*"):
            if file_path.is_file() and not self.is_ignored(file_path):
                try:
                    self.upload_file(file_path)
                    uploaded += 1
                except Exception as e:
                    print(f"⚠️  Failed to upload {file_path}: {e}")
        print(f"✅ Uploaded local files: {uploaded}")
    
    def sync_changes(self):
        """Process queued changes"""
        with self.sync_lock:
            if not self.sync_queue:
                return
                
            print(f"🔄 Syncing {len(self.sync_queue)} changes...")
            
            # Process each queued item
            for item in list(self.sync_queue):
                path, action = item
                try:
                    if action == "deleted":
                        if Path(path).exists():
                            continue  # File still exists, skip deletion
                        self.delete_file(path)
                    elif Path(path).exists():
                        self.upload_file(path)
                except Exception as e:
                    print(f"❌ Sync error for {path}: {e}")
            
            self.sync_queue.clear()
            print("✅ Sync completed")
    
    def queue_sync(self, file_path, action):
        """Queue a file for sync after delay"""
        with self.sync_lock:
            self.sync_queue.add((str(file_path), action))
            
            # Cancel existing timer
            if self.sync_timer:
                self.sync_timer.cancel()
            
            # Set new timer for 30 seconds
            self.sync_timer = threading.Timer(30.0, self.sync_changes)
            self.sync_timer.start()
    
    def process_existing_files(self):
        """Process all existing files on startup"""
        print("🔍 Processing existing files...")
        for file_path in self.local_folder.rglob("*"):
            if file_path.is_file() and not self.is_ignored(file_path):
                self.upload_file(file_path)
        print("✅ Existing files processed")

class FileChangeHandler(FileSystemEventHandler):
    def __init__(self, monitor):
        self.monitor = monitor
    
    def on_modified(self, event):
        if not event.is_directory and not self.monitor.is_ignored(Path(event.src_path)):
            print(f"✏️  Modified: {event.src_path}")
            self.monitor.queue_sync(event.src_path, "modified")
    
    def on_created(self, event):
        if not event.is_directory and not self.monitor.is_ignored(Path(event.src_path)):
            print(f"➕ Created: {event.src_path}")
            self.monitor.queue_sync(event.src_path, "created")
    
    def on_deleted(self, event):
        if not self.monitor.is_ignored(Path(event.src_path)):
            print(f"🗑️  Deleted: {event.src_path}")
            self.monitor.queue_sync(event.src_path, "deleted")
    
    def on_moved(self, event):
        print(f"➡️  Moved: {event.src_path} → {event.dest_path}")
        if not event.is_directory and not self.monitor.is_ignored(Path(event.dest_path)):
            # Delete old file
            self.monitor.queue_sync(event.src_path, "deleted")
            # Upload new file
            self.monitor.queue_sync(event.dest_path, "created")

def main():
    # Configuration
    import os
    from dotenv import load_dotenv
    
    # Load environment variables from .env file if it exists
    load_dotenv()
    
    # Get configuration from environment variables or use defaults
    LOCAL_FOLDER = os.getenv("LOCAL_FOLDER", r"C:\Users\RDP\Downloads\chat-backup\chat-server (2)\chat-server")
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
    REPO_NAME = os.getenv("REPO_NAME", "rdp269-bot/chat-server")
    
    # Validate GitHub token
    if not GITHUB_TOKEN:
        print("❌ Error: GitHub token not found.")
        print("Please create a .env file in the script directory with the following content:")
        print("--- .env ---")
        print(f"GITHUB_TOKEN=your_github_token_here")
        print(f"LOCAL_FOLDER={LOCAL_FOLDER}")
        print(f"REPO_NAME={REPO_NAME}")
        print("------------")
        print("You can create a token at: https://github.com/settings/tokens")
        print("Required permissions: repo (full control of private repositories)")
        return
    
    try:
        # Create monitor instance
        monitor = FolderMonitor(LOCAL_FOLDER, GITHUB_TOKEN, REPO_NAME)

        # Reset remote repo and upload everything once
        print("🧹 Resetting remote repository (deleting all files)...")
        monitor.delete_all_repo_files()
        print("⬆️  Uploading all local files (ignoring node_modules, .venv, etc.)...")
        monitor.upload_all_local_files()
        print("✅ Initial upload complete")

    except Exception as e:
        print(f"❌ Failed to initialize folder monitor: {e}")
        print("Please check your GitHub token and repository name and try again.")
        return
    
    # Set up file watcher
    event_handler = FileChangeHandler(monitor)
    observer = Observer()
    observer.schedule(event_handler, str(monitor.local_folder), recursive=True)
    
    # Start monitoring
    observer.start()
    print("👀 Folder monitoring started. Press Ctrl+C to stop.")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Stopping monitor...")
        observer.stop()
        # Force sync any pending changes
        if monitor.sync_timer:
            monitor.sync_timer.cancel()
        monitor.sync_changes()
    
    observer.join()

if __name__ == "__main__":
    main()
